
import unittest
from unittest.mock import patch, MagicMock
from horseclub_app_refactored import feed_horses_ui, groom_horse_ui, reward_level_ui, competition_ui

class TestHorseClubUI(unittest.TestCase):

    @patch("horseclub_app_refactored.st")
    def test_feed_horses_ui(self, mock_st):
        profile = {"fed": False}
        mock_st.button.return_value = True
        feed_horses_ui(profile, voice_on=False)
        self.assertTrue(profile["fed"])
        mock_st.success.assert_called_with("Hästarna har fått mat och vatten!")

    @patch("horseclub_app_refactored.st")
    def test_groom_horse_ui(self, mock_st):
        profile = {"horses": {"Bella": False}}
        mock_st.button.return_value = True
        mock_st.columns.return_value = [MagicMock(), MagicMock()]
        groom_horse_ui("Bella", profile, voice_on=False)
        self.assertTrue(profile["horses"]["Bella"])
        mock_st.success.assert_called_with("Bella är nu ryktad!")

    @patch("horseclub_app_refactored.st")
    def test_reward_level_ui(self, mock_st):
        reward_level_ui(20)
        mock_st.success.assert_called_with("🏆 Du har fått en pokal!")

        reward_level_ui(10)
        mock_st.success.assert_called_with("🎖️ Du har fått en medalj!")

        reward_level_ui(5)
        mock_st.success.assert_called_with("🎁 Du har fått en rosett!")

    @patch("horseclub_app_refactored.st")
    def test_competition_ui(self, mock_st):
        profile = {"stars": 10}
        mock_st.button.return_value = True
        competition_ui(profile, voice_on=False)
        self.assertEqual(profile["stars"], 11)
        mock_st.success.assert_called_with("🎉 Du vann en extra ⭐ i tävlingen!")

if __name__ == "__main__":
    unittest.main()
