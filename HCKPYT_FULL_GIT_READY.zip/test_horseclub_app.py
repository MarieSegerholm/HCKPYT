
import unittest
import os
import json
from horseclub_app_refactored import get_filename, load_profile, save_profile

class TestHorseClubApp(unittest.TestCase):
    def setUp(self):
        self.name = "TestBarn"
        self.pin = "1234"
        self.filename = get_filename(self.name, self.pin)

    def tearDown(self):
        if os.path.exists(self.filename):
            os.remove(self.filename)

    def test_profile_creation(self):
        profile = load_profile(self.name, self.pin)
        self.assertIsInstance(profile, dict)
        self.assertEqual(profile["stars"], 0)
        self.assertFalse(profile["fed"])
        self.assertFalse(profile["task_done"])
        self.assertEqual(profile["horses"], {"Bella": False, "Stjärna": False, "Maja": False})

    def test_profile_saving_and_loading(self):
        profile = load_profile(self.name, self.pin)
        profile["stars"] = 5
        save_profile(self.name, self.pin, profile)
        loaded = load_profile(self.name, self.pin)
        self.assertEqual(loaded["stars"], 5)

if __name__ == '__main__':
    unittest.main()
