
# 🐴 HorseClub Kids – DELUXE

![Tests](https://github.com/MarieSegerholm/HCKPYT/actions/workflows/python-app.yml/badge.svg)

Ett barnvänligt hästäventyr byggt med Python och Streamlit för barn mellan 5–14 år.

## 🎯 Funktioner
- Skapa profil (namn + PIN)
- Daglig skötsel av hästar (mata, rykta)
- Belöningssystem med ⭐, rosett, medalj och pokal
- Kalender med aktivitetslogg
- Tävlingar låses upp efter 10 stjärnor
- Röstförklaringar via webbläsarens talsyntes

## 🚀 Kom igång
1. Installera beroenden:
   ```bash
   pip install streamlit
   ```

2. Kör appen:
   ```bash
   streamlit run horseclub_app.py
   ```

3. Kör tester:
   ```bash
   python -m unittest discover -s . -p "test_*.py"
   ```

## 🧪 Tester
Automatiska tester körs via [GitHub Actions](https://github.com/MarieSegerholm/HCKPYT/actions).

## 📂 Struktur
```
HCKPYT/
├── horseclub_app.py
├── test_horseclub_app.py
├── test_horseclub_ui.py
├── bilder/
└── .github/
    └── workflows/
        └── python-app.yml
```

## 🧠 Inspirationskällor
- Clean Code – Robert C. Martin
- Refactoring – Martin Fowler
- Effective Python – Brett Slatkin
- Design Patterns – GoF

## ✨ Streamlit Cloud
[https://hck250517.streamlit.app](https://hck250517.streamlit.app)

## 📬 GitHub Repo
[https://github.com/MarieSegerholm/HCKPYT](https://github.com/MarieSegerholm/HCKPYT)
